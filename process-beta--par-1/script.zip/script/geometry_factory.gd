@tool
extends Node3D
class_name GeometryFactory

# Node parent qui recevra toutes les formes générées
@onready var generated_root: Node3D = $"../Generated"


func _ready():
	# === TEST SIMPLE ===
	var mes_reglages := {
		"type": "box",
		"position": Vector3(0, 2, 0),
		"rotation": Vector3.ZERO,
		"size": Vector3(2, 4, 2),
		"collision": true
	}
	create_shape(mes_reglages)


# ==================================================
# API PUBLIQUE POUR L’IA
# ==================================================
# params attendus :
# {
#   "type": "box" | "cylinder" | "plane"
#   "position": Vector3
#   "rotation": Vector3 (en degrés)
#   "size": Vector3
#   "collision": bool
# }

func create_shape(params: Dictionary) -> Node3D:
	var shape_type: String = params.get("type", "box")
	var position: Vector3 = params.get("position", Vector3.ZERO)
	var rotation: Vector3 = params.get("rotation", Vector3.ZERO)
	var size: Vector3 = params.get("size", Vector3.ONE)
	var with_collision: bool = params.get("collision", true)

	# =====================
	# NODE VISUEL
	# =====================
	var visual := MeshInstance3D.new()
	visual.position = position
	visual.rotation_degrees = rotation

	var mesh: Mesh
	var collision_shape: Shape3D


	match shape_type:

		# =====================
		# BOX / CUBE
		# =====================
		"box":
			var m := BoxMesh.new()
			m.size = size
			mesh = m

			var s := BoxShape3D.new()
			s.size = size
			collision_shape = s


		# =====================
		# CYLINDER / TOUR
		# =====================
		"cylinder":
			var m := CylinderMesh.new()
			m.top_radius = size.x * 0.5
			m.bottom_radius = size.x * 0.5
			m.height = size.y
			mesh = m

			var s := CylinderShape3D.new()
			s.radius = size.x * 0.5
			s.height = size.y
			collision_shape = s


		# =====================
		# PLANE / SOL / TOIT
		# =====================
		"plane":
			var m := PlaneMesh.new()
			m.size = Vector2(size.x, size.z)
			mesh = m

			var s := BoxShape3D.new()
			s.size = Vector3(size.x, 0.2, size.z)
			collision_shape = s


		_:
			push_error("Type de forme inconnu : " + shape_type)
			return null


	# =====================
	# ASSIGNATION VISUELLE
	# =====================
	visual.mesh = mesh
	generated_root.add_child(visual)


	# =====================
	# COLLISION (OPTIONNELLE)
	# =====================
	if with_collision:
		var body := StaticBody3D.new()
		var col := CollisionShape3D.new()
		col.shape = collision_shape
		body.add_child(col)
		visual.add_child(body)

	return visual


# ==================================================
# UTILITAIRES
# ==================================================

func clear_all() -> void:
	for c in generated_root.get_children():
		c.queue_free()
