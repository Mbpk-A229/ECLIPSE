extends Node
@onready var spawner = $"../EnvironmentSpawner"


func _ready() -> void:
	await get_tree().process_frame

	# ===============================
	# EXEMPLE : élément placé précisément
	# (ex: un arbre qui bloque un chemin, sert de repère, etc.)
	# ===============================
	#spawner.spawn_element("tree_oak", Vector3(12, 0, 4), {
	#	"scale": 1.2,
	#	"rotation_y": deg_to_rad(45)
	#})

	# ===============================
	# EXEMPLE : dispersion de fond
	# ===============================
	#spawner.spawn_scatter("tree_pine", Vector3.ZERO, 200.0, 80, 6.0)
	#spawner.spawn_scatter("rock_a", Vector3.ZERO, 200.0, 20, 5.0)

	# Une forêt de pins en arrière-plan, sur une zone de 200x200,
	# 80 pins, espacés d'au moins 6 unités les uns des autres
	spawner.spawn_scatter("tree_pine_a", Vector3(10, 0, 5), 200.0, 80, 6.0, {
		"scale_min": 0.9,
		"scale_max": 1.4,
		"randomize_rotation": true
	})
