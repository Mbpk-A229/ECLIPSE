extends Node

@onready var spawner = $"../NPCSpawner"

var worker_a : Enemy
var worker_b : Enemy
var worker_c : Enemy
var soldier_a: Enemy
var soldier_b: Enemy
var woman_a:Enemy
var marie :Enemy
var aure: Enemy
var rosales: Enemy
var arissa: Enemy
var bryce_a: Enemy
var david_a: Enemy
var lewis_a: Enemy
var zombie_group_1 : Array = []
var zombie_group_2 : Array = []
var mutan_group_1 : Array = []


func _ready() -> void:
	await get_tree().process_frame
	woman_a = spawner.spawn_npc("woman", Vector3(19, 0, 8), {
		"walk_speed": 0.5,
		"notice_raduis": 15.0,
		"can_flee" : false ,
		"can_chase": false,
		"can_attack":false,
		"can_move":false,
		'can_move_to_target':true,
		"target_position": Vector3(10, 0, 3)
	})
	
	worker_b = spawner.spawn_npc("worker", Vector3(6, 0, 6), {
		"walk_speed": 0.75,
		"notice_raduis": 13.0,
		"can_move": false,
		"can_attack":false,
		"can_flee":true,
	})
	
	 
	
	arissa = spawner.spawn_npc("arissa", Vector3(15, 0, 8), {
		"walk_speed": 0.5,
		"notice_raduis": 15.0,
		"can_chase": false,
		"can_attack":false,
		"can_flee":false,
		"can_move": false,
		#"target": worker_b,
		#'can_move_to_target':true,
		#"target_position": Vector310, 0, 3)
		
		
	}) 
	
	aure = spawner.spawn_npc("aure", Vector3(13, 0, 7), {
		"walk_speed": 0.75,
		"notice_raduis": 13.0,
		"can_move": false,
		"can_chase":false ,
		"can_attack":false,
		#"target": worker_c,
		#"can_move_to_target":true,
	})
	
	marie = spawner.spawn_npc("marie", Vector3(19, 0, -3), {
		"walk_speed": 0.75,
		"notice_raduis": 13.0,
		"can_move": false,
		"can_chase":false ,
		"can_attack":true,
		"target": woman_a,
		"can_move_to_target":true,
	})
	
	rosales = spawner.spawn_npc("rosales", Vector3(22, 0, 6), {
		"walk_speed": 0.75,
		"notice_raduis": 13.0,
		"can_move": true,
		"can_chase":false ,
		"can_attack":true,
		#"target": woman_a,
		#"can_move_to_target":true,
	})
	
	zombie_group_1 = await spawner.spawn_group("zombie_a", "zombie_group_1", Vector3(10, 0, 5), {
	"number": 5,
	"can_move": false,
	"can_chase": true,
	"notice_raduis": 12.0
	})
	
	mutan_group_1 = await spawner.spawn_group("mutan", "mutan_group_1", Vector3(10, 0, 5), {
	"number": 1,
	"can_move": true,
	"can_chase": false,
	"notice_raduis": 12.0
	})
	
	zombie_group_2 = await spawner.spawn_group("zombie_b", "zombie_group_2", Vector3(20, 0, 10), {
	"number": 3,
	"can_move": true,
	"can_chase": true,
	"notice_raduis": 12.0
	})
	
	soldier_a = spawner.spawn_npc("soldier", Vector3(20, 0, 4), {
		"walk_speed": 0.5,
		"notice_raduis": 15.0,
		"can_chase": false,
		"can_attack":true,
		"can_flee":false,
		#"can_move": true,
		#"target_group": "zombie_group_1",
		#"target": worker_b,
		#'can_move_to_target':true,
		#"target_position": Vector310, 0, 3)
		
		
	})
	
	worker_a = spawner.spawn_npc("worker", Vector3(15, 0, 3), {
		"walk_speed": 3.5,
		"notice_raduis": 15.0,
		"can_flee" : false,
		"can_chase": false,
		"can_attack":true,
		"target": worker_b,
		"can_move_to_target":true,
		
		
	})
	
	
	bryce_a = spawner.spawn_npc("bryce", Vector3(17, 0, 9), {
		"walk_speed": 3.5,
		"notice_raduis": 15.0,
		"can_flee" : false,
		"can_chase": false,
		"can_attack":true,
		"weapon": "bat",
		#"target": worker_b,
		#"can_move_to_target":true,
		
		
	})
	
	david_a = spawner.spawn_npc("david", Vector3(19, 0, 9), {
		"walk_speed": 3.5,
		"notice_raduis": 15.0,
		"can_flee" : false,
		"can_chase": false,
		"can_attack":true,
		"weapon": "knife",
		#"target": worker_b,
		#"can_move_to_target":true,
		
		
	})
	
	lewis_a = spawner.spawn_npc("lewis", Vector3(26, 0, 9), {
		"walk_speed": 3.5,
		"notice_raduis": 15.0,
		"can_flee" : false,
		"can_chase": false,
		"can_attack":true,
		"weapon": "knife",
		#"target": worker_b,
		#"can_move_to_target":true,
		
		
	})
	
	
	
	worker_c = spawner.spawn_npc("worker", Vector3(7, 0, 7), {
		"walk_speed": 0.75,
		"notice_raduis": 13.0,
		"can_flee": false,
		"can_attack":false,
	})
